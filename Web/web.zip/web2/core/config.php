<?php
$host = "mysql";
$username = "root";
$password = "pass";
$dbname = "web2";
?>
