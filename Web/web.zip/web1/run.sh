docker run -d -p 8001:80 -v /home/oitctf/web1/html:/var/www/html --name web1 php:7.3.4-apache
