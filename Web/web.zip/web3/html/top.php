<h1>Hello World!</h1>
<ul>
	<li class="menu"><a href="?page=ada" class="link">Ada</a></li>
	<li class="menu"><a href="?page=assembler" class="link">Assembler(x86)</a></li>
	<li class="menu"><a href="?page=brainfuck" class="link">brainfuck</a></li>
	<li class="menu"><a href="?page=c" class="link">C</a></li>
	<li class="menu"><a href="?page=c#" class="link">C#</a></li>
	<li class="menu"><a href="?page=cpp" class="link">C++</a></li>
	<li class="menu"><a href="?page=cobol" class="link">COBOL</a></li>
	<li class="menu"><a href="?page=coffeescript" class="link">CoffeeScript</a></li>
	<li class="menu"><a href="?page=d" class="link">D</a></li>
	<li class="menu"><a href="?page=erlang" class="link">Erlang</a></li>
	<li class="menu"><a href="?page=fortran" class="link">Fortran</a></li>
	<li class="menu"><a href="?page=flag" class="link">flag</a></li>
	<li class="menu"><a href="?page=go" class="link">Go</a></li>
	<li class="menu"><a href="?page=haskell" class="link">Haskell</a></li>
	<li class="menu"><a href="?page=io" class="link">Io</a></li>
	<li class="menu"><a href="?page=java" class="link">Java</a></li>
	<li class="menu"><a href="?page=javascript" class="link">JavaScript</a></li>
	<li class="menu"><a href="?page=ocaml" class="link">OCaml</a></li>
	<li class="menu"><a href="?page=pascal" class="link">Pascal</a></li>
	<li class="menu"><a href="?page=prolog" class="link">Prolog</a></li>
	<li class="menu"><a href="?page=r" class="link">R</a></li>
	<li class="menu"><a href="?page=ruby" class="link">Ruby</a></li>
	<li class="menu"><a href="?page=rust" class="link">Rust</a></li>
	<li class="menu"><a href="?page=scala" class="link">Scala</a></li>
	<li class="menu"><a href="?page=scheme" class="link">Scheme</a></li>
	<li class="menu"><a href="?page=smalltalk" class="link">Smalltalk</a></li>
	<li class="menu"><a href="?page=visualbasic" class="link">Visual Basic.net</a></li>
</ul>
