<pre><code>
%% hello.erl

-module(hello).
-export([start/0]).
start() -> io:fwrite("Hello, World!\n").
</code></pre>
