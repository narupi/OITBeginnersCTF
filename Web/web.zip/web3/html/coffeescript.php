<pre><code>
# hello.coffee

hello = ->
	console.log("Hello, World!")

hello()
</code></pre>
