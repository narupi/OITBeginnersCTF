<?php 
//Flag: oitctf{Vulnerable_PHP}

?>
<pre><code>
//hello.flag
Flag is hidden in "flag.php".
Can you read the "flag.php"?
</code></pre>
