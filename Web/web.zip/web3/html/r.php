<pre><code>
# hello.r

print("Hello, World!")
</code></pre>
