<pre><code>
// hello.io

"Hello, World" println
</code></pre>
