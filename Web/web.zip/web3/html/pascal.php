<pre><code>
{ hello.pas }

program hello;

begin
	WriteLn('Hello, World!');
end.
</code></pre>
