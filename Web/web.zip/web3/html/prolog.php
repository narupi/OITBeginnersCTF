<pre><code>
/* hello.pl */

:- initialization(main).
main :- write('Hello, World!'), nl, halt.
</code></pre>
