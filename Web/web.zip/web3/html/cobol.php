<pre><code>
123456*8901234567890123456789012345678901234567890
      * hello.cob
       IDENTIFICATION  DIVISION.
       PROGRAM-ID.     HELLO.
       PROCEDURE       DIVISION.
           DISPLAY "Hello, World!".
           STOP   RUN.
</code></pre>
