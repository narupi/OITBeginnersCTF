<pre><code>
// hello.go

package main

import "fmt"

func main() {
	fmt.Print("Hello, World!\n")
}
</code></pre>
