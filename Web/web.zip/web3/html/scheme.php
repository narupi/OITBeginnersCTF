<pre><code>
;hello.scm

(display "Hello, World!")
(newline)
</code></pre>
