<pre><code>
! hello.f90

PROGRAM HELLO
	PRINT *, 'Hello, World!'
END PROGRAM
</code></pre>
