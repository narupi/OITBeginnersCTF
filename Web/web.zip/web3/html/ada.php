<pre><code>
-- hello.adb

with Ada.Text_IO; use Ada.Text_IO;
procedure Hello is
begin
	Put_Line("Hello, World!");
end Hello;
</code></pre>
