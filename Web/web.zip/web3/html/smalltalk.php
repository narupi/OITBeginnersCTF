<pre><code>
"hello.st"

Transcript show: 'Hello, World!'; cr
</code></pre>
