<pre><code>
//hello.rs
fn main() {
    println!("Hello World!");
}
</code></pre>
