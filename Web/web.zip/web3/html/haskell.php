<pre><code>
-- hello.hs

main=putStrLn "Hello, World!"
</code></pre>
