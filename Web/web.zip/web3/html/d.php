<pre><code>
// hello.d

private import std.stdio;

void main()
{
	writeln("Hello, World!");
}
</code></pre>
