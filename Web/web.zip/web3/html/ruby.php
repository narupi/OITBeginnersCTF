<pre><code>
# hello.rb

puts "Hello, World!"
</code></pre>
