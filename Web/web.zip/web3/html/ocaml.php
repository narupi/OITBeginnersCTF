<pre><code>
(* hello.ml *)

print_string "Hello, World\n"
</code></pre>
