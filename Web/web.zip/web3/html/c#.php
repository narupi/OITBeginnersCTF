<pre><code>
// hello.cs

using System;

class HelloWorld
{
	[STAThread]
	static void Main(string[] args)
	{
		Console.WriteLine("Hello, World!");
	}
}
</code></pre>
